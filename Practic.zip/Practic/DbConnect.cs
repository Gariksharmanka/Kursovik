﻿using System;
using Practic.DataBase;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Practic
{
    class DbConnect
    {
        public static Practic05Entities prObj;
    }
}
