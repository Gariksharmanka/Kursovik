﻿using Practic.DataBase;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Practic.Pages
{
    /// <summary>
    /// Логика взаимодействия для Guest.xaml
    /// </summary>
    public partial class Guest : Page
    {
        private List<Material> allItems;
        public Guest()
        {

            InitializeComponent();
            allItems = DbConnect.prObj.Material.ToList();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            FrameApp.frmObj.Navigate(new Auth());
        }

        private void ComboBox_SelectionChanged()
        {

        }

        private void ComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

            {
                if (CmbSort.SelectedIndex == 0)
                {
                    List<Material> sortMaterials = allItems.OrderBy(x => x.Title).ToList();
                    MaterialList.ItemsSource = sortMaterials;
                }
                else if (CmbSort.SelectedIndex == 1)
                {
                    List<Material> sortMaterials = allItems.OrderByDescending(x => x.Title).ToList();
                    MaterialList.ItemsSource = sortMaterials;
                }
                else if (CmbSort.SelectedIndex == 2)
                {
                    List<Material> sortMaterials = allItems.OrderBy(x => x.MinCount).ToList();
                    MaterialList.ItemsSource = sortMaterials;
                }
                else if (CmbSort.SelectedIndex == 3)
                {
                    List<Material> sortMaterials = allItems.OrderByDescending(x => x.MinCount).ToList();
                    MaterialList.ItemsSource = sortMaterials;
                }
                else if (CmbSort.SelectedIndex == 4)
                {
                    List<Material> sortMaterials = allItems.OrderBy(x => x.Cost).ToList();
                    MaterialList.ItemsSource = sortMaterials;
                }
                else if (CmbSort.SelectedIndex == 5)
                {
                    List<Material> sortMaterials = allItems.OrderByDescending(x => x.Cost).ToList();
                    MaterialList.ItemsSource = sortMaterials;
                }
            }

        }

        private void TxbSearch_TextChanged_1(object sender, TextChangedEventArgs e)
        {
            {
                try
                {
                    MaterialList.ItemsSource = DbConnect.prObj.Material.Where(x => x.Title.Contains(TxbSearch.Text)).Take(15).ToList();
                    ResultTXB.Text = MaterialList.Items.Count + "/" + DbConnect.prObj.Material.Where(x => x.Title.Contains(TxbSearch.Text)).Count().ToString();
                }
                catch (Exception ex)
                {
                    throw;
                }
            }
        }

        private void CmbFilter_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            var select = CmbFilter.SelectedItem as MaterialType;
            var items = (select != null) ? allItems.Where(x => x.MaterialTypeID == select.ID) : allItems;
            MaterialList.ItemsSource = items;
            
        }

        private void ListView_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            try
            {
                CmbFilter.ItemsSource = DbConnect.prObj.MaterialType.ToList();
                CmbFilter.DisplayMemberPath = "Title";
                CmbFilter.SelectedIndex = 0;
                CmbFilter.SelectedIndex = 0;

                MaterialList.ItemsSource = DbConnect.prObj.Material.ToList();

                ResultTXB.Text = MaterialList.Items.Count + "/" + DbConnect.prObj.Material.Count().ToString();
            }
            catch
            {
                MessageBox.Show("Упс, что-то пошло не так! ;)",
                    "Уведомление",
                    MessageBoxButton.OK,
                    MessageBoxImage.Information);
            }
        }

        private void Page_Loaded(object sender, RoutedEventArgs e)
        {

        }

        private void BtnNext_Click(object sender, RoutedEventArgs e)
        {
            FrameApp.frmObj.Navigate(new Order());
        }
    }
}
